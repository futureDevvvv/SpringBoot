package net.softsociety.issho.service;

import net.softsociety.issho.domain.Member;

public interface MemberService {
	
	public int insert(Member member); 
}
