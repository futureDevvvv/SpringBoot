package net.softsociety.issho.chat;

public class ChatMessage {

	String chatRoomId;
	String message;
	String type;
	
	
	public String getChatRoomId() {
		// TODO Auto-generated method stub
		return chatRoomId;
	}
	
	public String getMessage() {
		return message;
	}

	public String getType() {
		// TODO Auto-generated method stub
		return type;
	}

}
