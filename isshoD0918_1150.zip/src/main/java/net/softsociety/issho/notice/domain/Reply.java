package net.softsociety.issho.notice.domain;

public class Reply {
	int noticeCmt_seq;
	int notice_seq;
	String noticeCmt_writer;
	String noticeCmt_contents;
	String noticeCmt_date;
}