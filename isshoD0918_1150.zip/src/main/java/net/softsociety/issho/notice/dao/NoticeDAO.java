package net.softsociety.issho.notice.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.RowBounds;

import net.softsociety.issho.notice.domain.Notice;
import net.softsociety.issho.notice.domain.NoticeDetail;
import net.softsociety.issho.notice.domain.Reply;

@Mapper
public interface NoticeDAO {
	public ArrayList<NoticeDetail> listNotice(HashMap<String, String> map, RowBounds rb);

	public int countNotice(HashMap<String, String> map);

	public int insertNotice(Notice notice);
	
	public NoticeDetail selectNotice(int notice_seq);
	
	public int deleteNotice(Notice notice);
	
	public int updateNotice(Notice notice);
	
	public int insertReply(Reply reply);
	
	public ArrayList<Reply> selectReplyList(int noticeCmt_seq);
	
	public int deleteReply(Reply reply);

	public int updateHits(int notice_seq);
}
