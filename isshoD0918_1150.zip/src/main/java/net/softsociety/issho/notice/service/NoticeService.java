package net.softsociety.issho.notice.service;

import java.util.ArrayList;

import net.softsociety.issho.notice.domain.Notice;
import net.softsociety.issho.notice.domain.NoticeDetail;
import net.softsociety.issho.notice.domain.Reply;
import net.softsociety.issho.util.PageNavigator;

public interface NoticeService {
	public int writeNotice(Notice notice);
	
	public ArrayList<NoticeDetail> listNotice(PageNavigator navi, String type, String searchWord, String prj_domain);

	public int insertNotice(Notice notice);
	
	public NoticeDetail selectNotice(int notice_seq);
	
	public NoticeDetail readNotice(int notice_seq, boolean increaseHits);
	
	public int deleteNotice(Notice notice);
	
	public int updateNotice(Notice notice);

	public int insertReply(Reply reply);
	
	public ArrayList<Reply> selectReplyList(int noticeCmt_seq);
	
	public int deleteReply(Reply reply);

	PageNavigator getPageNavigator(int pagePerGroup, int countPerPage, int page, String type, String searchWord, String prj_domain);

	public int write(NoticeDetail noticeDetail);

}
